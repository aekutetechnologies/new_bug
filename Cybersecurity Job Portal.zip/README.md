
  # Cybersecurity Job Portal

  This is a code bundle for Cybersecurity Job Portal. The original project is available at https://www.figma.com/design/5v4Uxmhfkb1ormwT72rVPz/Cybersecurity-Job-Portal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  