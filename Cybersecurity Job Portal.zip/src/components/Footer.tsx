import { Shield, Twitter, Linkedin, Github, Mail } from "lucide-react";

export function Footer() {
  const footerLinks = {
    "For Job Seekers": [
      { label: "Browse Jobs", href: "#" },
      { label: "Create Profile", href: "#" },
      { label: "Career Resources", href: "#" },
      { label: "Success Stories", href: "#" },
    ],
    "For Companies": [
      { label: "Post a Job", href: "#" },
      { label: "Pricing", href: "#" },
      { label: "Find Talent", href: "#" },
      { label: "Enterprise", href: "#" },
    ],
    "Company": [
      { label: "About Us", href: "#" },
      { label: "Blog", href: "#" },
      { label: "Careers", href: "#" },
      { label: "Contact", href: "#" },
    ],
    "Legal": [
      { label: "Privacy Policy", href: "#" },
      { label: "Terms of Service", href: "#" },
      { label: "Cookie Policy", href: "#" },
      { label: "GDPR", href: "#" },
    ],
  };

  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 mb-12">
          {/* Logo and Description */}
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="h-8 w-8 text-indigo-600" />
              <span className="text-gray-900">Bugbear</span>
            </div>
            <p className="text-gray-600 mb-4">
              The premier platform for cybersecurity professionals and companies to connect and grow.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Github className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-600 transition-colors">
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-gray-900 mb-4">{category}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-gray-600 hover:text-indigo-600 transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-gray-600">
            © 2025 Bugbear. All rights reserved.
          </p>
          <p className="text-gray-600">
            Made with ❤️ for the cybersecurity community
          </p>
        </div>
      </div>
    </footer>
  );
}
