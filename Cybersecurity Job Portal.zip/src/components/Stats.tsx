export function Stats() {
  const stats = [
    { value: "500+", label: "Active Jobs" },
    { value: "95%", label: "Remote Positions" },
    { value: "48h", label: "Average Response Time" },
    { value: "100%", label: "Vetted Companies" },
  ];

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-indigo-400 mb-2">{stat.value}</div>
              <div className="text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
