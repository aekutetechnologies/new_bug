import { Button } from "./ui/button";
import { ArrowRight, Search } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="max-w-2xl">
            <div className="inline-block px-4 py-1 bg-indigo-50 text-indigo-600 rounded-full mb-6">
              🔒 Secure Your Future in Cybersecurity
            </div>
            
            <h1 className="text-gray-900 mb-6">
              Connect with Top Cybersecurity Opportunities
            </h1>
            
            <p className="text-gray-600 mb-8">
              Bugbear is the premier platform connecting cybersecurity professionals with remote opportunities. 
              Find your next role or hire top talent to protect what matters most.
            </p>

            {/* Search Bar */}
            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search jobs (e.g., Penetration Tester)"
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
                />
              </div>
              <Button className="bg-indigo-600 hover:bg-indigo-700 px-8">
                Search Jobs
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="flex flex-wrap gap-8">
              <div>
                <div className="text-gray-900">500+</div>
                <div className="text-gray-600">Active Jobs</div>
              </div>
              <div>
                <div className="text-gray-900">200+</div>
                <div className="text-gray-600">Companies</div>
              </div>
              <div>
                <div className="text-gray-900">10k+</div>
                <div className="text-gray-600">Professionals</div>
              </div>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80"
                alt="Cybersecurity professional"
                className="w-full h-auto"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600">✓</span>
                </div>
                <div>
                  <div className="text-gray-900">Remote First</div>
                  <div className="text-gray-600">Work from anywhere</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
