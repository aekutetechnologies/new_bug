import { UserPlus, Search, Monitor, Briefcase } from "lucide-react";

export function HowItWorks() {
  const steps = [
    {
      icon: UserPlus,
      title: "Create Your Profile",
      description: "Sign up and build your professional profile with your skills, certifications, and experience.",
      color: "bg-blue-50 text-blue-600",
    },
    {
      icon: Search,
      title: "Browse Opportunities",
      description: "Explore hundreds of cybersecurity jobs from vetted companies looking for remote talent.",
      color: "bg-purple-50 text-purple-600",
    },
    {
      icon: Monitor,
      title: "Apply & Get Assigned VDI",
      description: "Submit your application and get instant VDI access upon approval to start working immediately.",
      color: "bg-green-50 text-green-600",
    },
    {
      icon: Briefcase,
      title: "Start Working",
      description: "Get hired and start working remotely on exciting cybersecurity projects worldwide.",
      color: "bg-indigo-50 text-indigo-600",
    },
  ];

  return (
    <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-gray-900 mb-4">
            How It Works
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Getting started is simple. Follow these four steps to launch your cybersecurity career.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-full">
                <div className={`w-12 h-12 ${step.color} rounded-lg flex items-center justify-center mb-4`}>
                  <step.icon className="h-6 w-6" />
                </div>
                
                <div className="absolute -top-3 -left-3 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center">
                  {index + 1}
                </div>
                
                <h3 className="text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
              
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gray-300 transform -translate-y-1/2" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
