import { Button } from "./ui/button";
import { ArrowRight } from "lucide-react";

export function CTA() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 to-gray-800">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-white mb-6">
          Ready to Start Your Cybersecurity Journey?
        </h2>
        <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
          Join thousands of cybersecurity professionals who have found their dream remote jobs through Bugbear. 
          Your next opportunity is just a click away.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button className="bg-indigo-600 hover:bg-indigo-700 px-8">
            Get Started for Free
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white hover:text-gray-900">
            Post a Job
          </Button>
        </div>

        <div className="mt-12 grid grid-cols-3 gap-8 max-w-2xl mx-auto pt-12 border-t border-gray-700">
          <div>
            <div className="text-white mb-1">Free to Join</div>
            <div className="text-gray-400">No hidden fees</div>
          </div>
          <div>
            <div className="text-white mb-1">24/7 Support</div>
            <div className="text-gray-400">Always here to help</div>
          </div>
          <div>
            <div className="text-white mb-1">Trusted</div>
            <div className="text-gray-400">By thousands</div>
          </div>
        </div>
      </div>
    </section>
  );
}
