import { Shield, Zap, Globe, Lock, TrendingUp, Monitor } from "lucide-react";

export function Features() {
  const features = [
    {
      icon: Shield,
      title: "Verified Companies",
      description: "All companies are thoroughly vetted to ensure legitimate opportunities and safe work environments.",
    },
    {
      icon: Globe,
      title: "100% Remote",
      description: "Work from anywhere in the world. All positions are fully remote with flexible schedules.",
    },
    {
      icon: Monitor,
      title: "Instant Workspaces",
      description: "Get VDI access immediately upon job approval to start working without any delays.",
    },
    {
      icon: Lock,
      title: "Secure Platform",
      description: "Your data is protected with enterprise-grade security. Privacy is our priority.",
    },
    {
      icon: Zap,
      title: "Fast Matching",
      description: "Our AI-powered system matches you with relevant opportunities in real-time.",
    },
    {
      icon: TrendingUp,
      title: "Career Growth",
      description: "Access resources, training, and mentorship to advance your cybersecurity career.",
    },
  ];

  return (
    <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-gray-900 mb-4">
            Why Choose Bugbear?
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We've built the most trusted platform for cybersecurity professionals and companies 
            to connect, collaborate, and grow together.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-6 rounded-xl border border-gray-200 hover:border-indigo-300 hover:shadow-lg transition-all"
            >
              <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center mb-4">
                <feature.icon className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
