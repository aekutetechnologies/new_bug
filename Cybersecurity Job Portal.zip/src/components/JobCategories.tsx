import { Button } from "./ui/button";
import { ArrowRight, Code, ShieldAlert, Bug, Network, Eye, Database } from "lucide-react";

export function JobCategories() {
  const categories = [
    {
      icon: ShieldAlert,
      title: "Penetration Testing",
      jobs: 127,
      color: "bg-indigo-50 text-indigo-600",
    },
    {
      icon: Code,
      title: "Security Engineering",
      jobs: 94,
      color: "bg-blue-50 text-blue-600",
    },
    {
      icon: Bug,
      title: "Bug Bounty Hunting",
      jobs: 56,
      color: "bg-purple-50 text-purple-600",
    },
    {
      icon: Network,
      title: "Network Security",
      jobs: 73,
      color: "bg-green-50 text-green-600",
    },
    {
      icon: Eye,
      title: "Security Analysis",
      jobs: 89,
      color: "bg-orange-50 text-orange-600",
    },
    {
      icon: Database,
      title: "Cloud Security",
      jobs: 112,
      color: "bg-cyan-50 text-cyan-600",
    },
  ];

  return (
    <section id="categories" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-gray-900 mb-4">
              Browse by Category
            </h2>
            <p className="text-gray-600">
              Find opportunities in your area of expertise
            </p>
          </div>
          <Button variant="ghost" className="hidden sm:flex items-center gap-2 text-indigo-600 hover:text-indigo-700">
            View All Categories
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => (
            <button
              key={index}
              className="p-6 rounded-xl border border-gray-200 hover:border-indigo-300 hover:shadow-lg transition-all text-left group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center`}>
                  <category.icon className="h-6 w-6" />
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
              </div>
              
              <h3 className="text-gray-900 mb-1">{category.title}</h3>
              <p className="text-gray-600">{category.jobs} open positions</p>
            </button>
          ))}
        </div>

        <div className="mt-8 sm:hidden">
          <Button variant="ghost" className="w-full flex items-center justify-center gap-2 text-indigo-600 hover:text-indigo-700">
            View All Categories
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}
